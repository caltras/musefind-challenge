module.exports = {
    "get" : {
        "/":function(req,res){
            res.render("login.html");
        }
    }
};