Vanhackathon

Challenge: Musefind (musefind.com)

Status: Incomplete

Team: Claudio Traspadini Oliveira

Language: Node.js



Install Nodejs in your machine (https://nodejs.org/en/download/package-manager/)

Open the terminal and browse to the project directory.

Install Packages (npm install)

Run project node server.js

