var server = require("./server/server");
server.init();
